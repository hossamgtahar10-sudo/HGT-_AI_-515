exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: corsHeaders(), body: '' };
  if (event.httpMethod !== 'POST') return response(405, { error: 'استخدم POST لإرسال السؤال.' });
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return response(500, { error: 'مفتاح Gemini غير مضبوط. أضف GEMINI_API_KEY في Environment variables على Netlify.' });
  let message;
  try { message = JSON.parse(event.body || '{}').message; } catch { return response(400, { error: 'صيغة الرسالة غير صحيحة.' }); }
  if (typeof message !== 'string' || !message.trim()) return response(400, { error: 'اكتب سؤالك أولًا.' });
  try {
    const upstream = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(apiKey), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: message.trim() }] }] })
    });
    const data = await upstream.json();
    if (!upstream.ok) return response(upstream.status, { error: data?.error?.message || 'خدمة الذكاء الاصطناعي رفضت الطلب.' });
    const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
    if (!reply) return response(502, { error: 'لم يصل رد نصي من Gemini. جرّب سؤالًا آخر.' });
    return response(200, { reply });
  } catch (err) { return response(502, { error: 'تعذر الاتصال بخدمة الذكاء الاصطناعي. حاول مرة أخرى.' }); }
};
function corsHeaders() { return { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Content-Type': 'application/json; charset=utf-8' }; }
function response(statusCode, data) { return { statusCode, headers: corsHeaders(), body: JSON.stringify(data) }; }
