HGT AI 515 — ملفات الموقع

الملفات:
- index.html: واجهة الموقع
- netlify/functions/chat.js: وظيفة الخادم التي تتصل بـ Gemini
- netlify.toml: إعدادات Netlify

مهم:
1) ارفع محتويات هذا المجلد إلى جذر مستودع GitHub (لا ترفع ملف ZIP وحده).
2) في Netlify > Project configuration > Environment variables أضف:
   Key: GEMINI_API_KEY
   Value: مفتاح Gemini الخاص بك
3) أعد النشر Deploy site.
4) لا تضع المفتاح داخل index.html ولا ترسله في الدردشة.
